  	package com.product.catalogue.entities;
interface Test{
	int i=0;
	public static void m1() {
		System.out.println("Static methods");
	}
	public static void m12() {
		System.out.println("Static methods");
	}
	public static void m13() {
		System.out.println("Static methods");
	}
	
	default void m2() {
		System.out.println("Default methods");
	}
	default void m121() {
		System.out.println("Default methods");
	}
	default void m1212() {
		System.out.println("Default methods");
	}
}

interface Test2{
	public static void m13() {
		System.out.println("Static methods");
	}
}
public class StaticMethod implements Test, Test2{
	
	public static void main(String...ss) {
		Test.m12();
		StaticMethod sm = new StaticMethod();
		sm.m2();
	}

}
