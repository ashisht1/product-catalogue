package com.product.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.product.catalogue.Exceptions.ProductException;
import com.product.catalogue.entities.Brand;
import com.product.catalogue.entities.Category;
import com.product.catalogue.entities.Color;
import com.product.catalogue.entities.Product;
import com.product.catalogue.service.ProductService;


@RestController
public class ProductController {
	
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/findAll/brands")
	public ResponseEntity<List<Brand>> findAllBrands() {
		List<Brand> list = productService.findAllBrands();

		return new ResponseEntity<List<Brand>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/findAll/colors")
	public ResponseEntity<List<Color>> findAllColors() {
		List<Color> list = productService.findAllColors();

		return new ResponseEntity<List<Color>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/findAll/categories")
	public ResponseEntity<List<Category>> findAllCategories() {
		List<Category> list = productService.findAllCategories();

		return new ResponseEntity<List<Category>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("findAll")
	public ResponseEntity<List<Product>> findAllProducts(){
		List<Product> list = productService.findAllProdcuts();
		
		return new ResponseEntity<List<Product>>(list,new HttpHeaders(), HttpStatus.OK);
	}
	
	
	@GetMapping("findAll/{filter}/{filterValue}")
	public ResponseEntity<List<Product>> findAllProductsByFilters(@PathVariable String filter, @PathVariable String filterValue){
		List<Product> list = productService.findAllProductsByFilters(filter,filterValue);
		
		if(list==null || list.isEmpty()) {
			throw new ProductException("Product not found");
		}
		return new ResponseEntity<List<Product>>(list,new HttpHeaders(), HttpStatus.OK);
	}
	
	

}
