package com.product.catalogue.service;

import java.util.List;

import com.product.catalogue.entities.Brand;
import com.product.catalogue.entities.Category;
import com.product.catalogue.entities.Color;
import com.product.catalogue.entities.Product;

public interface ProductService {

	List<Brand> findAllBrands();

	List<Color> findAllColors();

	List<Product> findAllProdcuts();

	List<Product> findAllProductsByFilters(String filter, String filterValue);

	List<Category> findAllCategories();

}
