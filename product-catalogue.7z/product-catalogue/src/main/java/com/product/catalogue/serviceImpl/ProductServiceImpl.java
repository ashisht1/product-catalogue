package com.product.catalogue.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.catalogue.entities.Brand;
import com.product.catalogue.entities.Category;
import com.product.catalogue.entities.Color;
import com.product.catalogue.entities.Product;
import com.product.catalogue.repository.BrandRepository;
import com.product.catalogue.repository.CategoryRepository;
import com.product.catalogue.repository.ColorRepository;
import com.product.catalogue.repository.ProductRepository;
import com.product.catalogue.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	BrandRepository brandRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	ColorRepository colorRepository;
	
	@Autowired
	ProductRepository productRepository;
	@Override
	public List<Brand> findAllBrands() {
		// TODO Auto-generated method stub
		return brandRepository.findAll();
	}

	@Override
	public List<Color> findAllColors() {
		// TODO Auto-generated method stub
		return colorRepository.findAll();
	}

	@Override
	public List<Product> findAllProdcuts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}
	
	
	@Override
	public List<Category> findAllCategories() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

	@Override
	public List<Product> findAllProductsByFilters(String filter, String filterValue) {
		// TODO Auto-generated method stub
		switch (filter) {
		case "Brand":
			return productRepository.findByBrandId(Integer.parseInt(filterValue));
		case "Color":
			return productRepository.findByColorId(Integer.parseInt(filterValue));
		case "Category":
			return productRepository.findByCategoryId(Integer.parseInt(filterValue));
		case "Size":
			return productRepository.findBySize(Integer.parseInt(filterValue));
		default:
			return null;
		}
		
	}

}
