package com.product.catalogue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.product.catalogue.entities.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{

	@Query("SELECT p FROM Product p JOIN FETCH p.color JOIN FETCH p.color WHERE p.colorId = :colorId")
	List<Product> findByColorId(@Param(value = "colorId") Integer colorId);
	
	@Query("SELECT p FROM Product p JOIN FETCH p.brand JOIN FETCH p.brand WHERE p.brandId = :brandId")
	List<Product> findByBrandId(@Param(value = "brandId") Integer brandId);
	
	@Query("SELECT p FROM Product p JOIN FETCH p.category JOIN FETCH p.category WHERE p.categoryId = :categoryId")
	List<Product> findByCategoryId(@Param(value = "categoryId") Integer categoryId);

	List<Product> findBySize(int parseInt);
}
